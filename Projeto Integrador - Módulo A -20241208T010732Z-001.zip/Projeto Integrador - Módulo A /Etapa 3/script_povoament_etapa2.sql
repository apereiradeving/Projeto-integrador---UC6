-- os scripts estão em ordem para inserção! :)

INSERT INTO nome_empresa (nomeempresa) VALUES 
('Uber'),   
('Ifood'),
('Amazon');

INSERT INTO Empresa (Nome, Porte, Tipo, Quant_Cargos, Quant_Func, Quant_app) VALUES 
('Uber', 'Grande', 'CLT', 'PJ', '4', '4', '4'),
('ifood', 'Grande', 'CLT', 'PJ', '4', '4',  '4'),
('Amazon', 'Grande', 'CLT', 'PJ', '4', '4', '4');

INSERT INTO ficha_do_funcionario (Nome, Tipo, Cargo, Empresa, E_mail, Data_nasc, Genero, Nick) VALUES
('Bianca de Lima Lopes',	'CLT', 'dev', 'Uber', 'ianca.lopes@gmail.com', '11/07/1976', 'F', 'bi_lima'),
('Rosali da Sousa Mattos', 'CLT', 'web-desing', 'Ifood', 'rosali.mattos@gmail.com', '05/10/1981', 'F', 'Ro_mattos'),
('Guilherme Silva Barreto, CLT, CEO, Amazon, guilherme.barreto@gmail.com, 28/02/1970, M, Gui_Sil'),
('Kauê Passos Giron', 'CLT', 'web-desing', 'Ifood', 'kaue.giron@gmail.com' '16/11/1997', 'M', 'Kauê.Barretos'),
('Ivania Cavalcanti Silva',	'CLT', 'dev', 'Uber','ivania.silva@gmail.com','14/08/1978','F','Iva_Sil'),
('Alisson Sacramento', 'CLT', 'CEO','Uber', 'Alisson.Sacramento@gmail.com',	'23/09/58', 'M', 'Ali_Sac'),
('Cármen Mata Camargo',	'PJ',	'CEO', 'Ifood', 'carmen.camargo@gmail,com', '04/10/1990', 'F', 'Caca.margo'),
('Evandro Trindade Bouça,' 'CLT', 'web-desing', 'Amazon', 'evandro.bouça@gmail.com', '06/08/1980', 'F', 'Eva.Tri'),
('Zilda Gomide Osório,CLT', 'dev',	'Amazon',	'zil.gomide@gmail.com',	'01/01/2000',	'F', 'Zil.Oso'),
('Francisca Parracho Caneira', 'PJ', 'web-desing', 'Uber', 'fran.caneira@gmail.com', '08/09/1995', 'F', 'Fran.Can'),
('Ivo Brandão Palos', 'PJ', 'dev', 'Ifood', 'ivo.palos@gmail.com', '07/02/1960', 'M', 'Ivo.Branl'),
('Eluany feitoza Rocha',	'PJ',	'dev', 'Amazon', 'any.feitoza@gmail.com',	'01/08/1975', 'F', 'anny_rocha');

INSERT INTO Cargo (Nome, Cargo, E_mail) VALUES
('Bianca de Lima Lopes', 'dev', 'bianca.lopes@gmail.com'),
('Rosali da Sousa Mattos', 'web-desing', 'rosali.mattos@gmail.com'),
('Guilherme Silva Barreto', 'CEO', 'guilherme.barreto@gmail.com'),
('Kauê Passos Giron', 'web-desing', 'kaue.giron@gmail.com'),
('Ivania Cavalcanti Silva', 'dev', 'ivania.silva@gmail.com'),
('Alisson Sacramento', 'CEO', 'Alisson.Sacramento@gmail.com'),
('Cármen Mata Camargo', 'CEO', 'carmen.camargo@gmail,com'),
('Evandro Trindade Bouça', 'web-desing', 'evandro.bouça@gmail.com'),
('Zilda Gomide Osório', 'dev', 'zil.gomide@gmail.com'),
('Francisca Parracho Caneira', 'web-desing', 'fran.caneira@gmail.com'),
('Ivo Brandão Palos', 'dev', 'ivo.palos@gmail.com'),
('Eluany feitoza Rocha, dev, any.feitoza@gmail.com');

INSERT INTO Dados_Empresa (Nome, Porte, Quant_cargo, Quant_func, Quant_no_app) VALUES
('Uber', 'Grande', '4', '4', '4'),
('ifood', 'Grande', 'CLT', 'PJ', '4', '4',  '4'),
('Amazon', 'Grande', 'CLT', 'PJ', '4', '4', '4');