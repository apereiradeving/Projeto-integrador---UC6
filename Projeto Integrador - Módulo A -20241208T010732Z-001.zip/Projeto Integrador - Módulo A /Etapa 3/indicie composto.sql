-- Criação de indice composto
-- indice composto na tabela cargo
Create index idx_cargo on   cargo(empresa_id, cargo_id);

Show index Cargo;
