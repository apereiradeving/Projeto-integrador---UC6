-- criando visões 

create VIEW vw_nomeempresa as
select tb_nome.empresa as nome 
from tb_nome
inner join tb_porte 
on tb_nome.ID_nome = tb_nomes.ID_empresa; 

select Nome, porte
from vw_NomePortes
Group by Nome; 

-- ALterando visões 

alter view vw_NomePortes  as 
select tb_nome.empresa as nome 
from tb_nomeempresa
join tb_Nome
on tb_nome.ID_nome = tb_nomes.ID_empresa; 

-- Exclusão de uma visão 
drop view  vw_nomeempresa;