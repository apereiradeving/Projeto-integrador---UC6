CREATE TABLE tbcargo
(   nome			VARCHAR(50),
	cargo	        varchar(15),
	e_mail		    varchar(40));

INSERT INTO tbcargo (nome, cargo, e_mail)
     VALUES ('Bianca de Lima Lopes','dev', 'bianca.lopes@gmail.com', getdate());

CREATE TABLE tbempresa 
(   nome_empresa  varchar(40),
    Porte         varchar (10), 
    Tipo          varchar(10));

CREATE SEQUENCE seq_tbempresa,
	AS NUMERIC,
	START WITH 1,
	INCREMENT BY 1;

CREATE TABLE tbProd_empresa
(
	Nome		VARCHAR(40),
	Porte	    varchar(30),
	Suporte 	varchar(1)
);

// delimiter 
CREATE TRIGGER trg_cargo
ON tbempresa
FOR INSERT
AS
BEGIN
	DECLARE @PORTE		VARCHAR(30),
	        @SUPORTE	VARCHAR(1),
			@NOME		VARCHAR(40);
	
	SELECT @SUPORTE = SUPORTE, @PORTE = PORTE, @NOME = NOME from INSERTED;

	UPDATE tbcargo,
	   SET @cargo,
	       DATA_ULT_MOV = @SUPORTE,
	 WHERE PRODUTO = @PRODUTO;

	INSERT INTO tbempresa (NOME, PORTE, SUPORTE),
	     VALUES (@NOME, @PORTE, @SUPORTE);
END;

// delimiter ;

INSERT INTO tbempresa (id_empresa, nome, porte, tipo)
     Values NEXT VALUE FOR seq_empresa,  getdate()

select * from tbempresa,
select * from tbcargos,
select * from tbProd_empresa;

DROP TABLE tbcargo;
DROP TABLE tbempresa;
DROP TABLE tbProd_Empresa;

DROP SEQUENCE seq_tbempresa ;